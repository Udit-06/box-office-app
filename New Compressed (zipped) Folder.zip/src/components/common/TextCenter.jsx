import styled from 'styled-components';

export const TextCenter = styled.div`
  text-align: center;
`;