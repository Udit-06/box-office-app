const Starred = () => {
    return <div>Starred page</div>;
}

export default Starred;